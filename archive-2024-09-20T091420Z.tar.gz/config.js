global.owner = ["6285895988045"];
global.mods = ["6285895988045"]; // Moderator
global.prems = ["6285895988045"]; // Premium
// YANG ATAS ITU UBAH JADI NOMOR LU
// & YG BAWAH INI, NOMOR,NAMA,EMAIL LU
global.fsizedoc = "450000000000"; // default 10TB
global.fpagedoc = "19";
global.numberbot = "62858959880459";
global.namedoc = "ALUXI - MD";
global.nameowner = "ALVIAN UXIO Inc.";
global.nomorown = "6285895988045";
global.dana = "6285895988045";
global.pulsa = "6285895988045";
global.ovo = "6285895988045";
global.saweria = "https://saweria.co/alvianuxio";
global.namebot = "ALUXI - MD";
global.sgc = "https://whatsapp.com/channel/0029VaAQKcJEquiQVH2RM10U";
global.sourceUrl = "https://whatsapp.com/channel/0029VaAQKcJEquiQVH2RM10U";
global.sig = "https://whatsapp.com/channel/0029VaAQKcJEquiQVH2RM10U";
global.swa = "wa.me/6285895988045";
global.gif = " "; //Ini buat gif yang di menu
global.icon = "https://a.uguu.se/bsTaWwgW.jpg";
global.thumb = "https://telegra.ph/file/6bcbacb886c0ca12c9e3b.jpg";
global.version = "16.2.1";
global.wm = "© ALUXI - MD 2023-2024";
global.watermark = wm;
global.lann = "p8ADYJib";
global.wm2 = "ALUXI - MD";
global.wm3 = namebot;
global.isPairing = true;
global.wm4 = namebot;
global.fla =
  "https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=";
global.wait = "*『 ⬡ ʟᴏᴀᴅɪɴɢ... 』*";
global.eror = "*[ SYSTEM ERROR ]*";
global.done = "```© ALUXI - MD 2023-2024```";
global.salah = "Salah\n";
global.web = global.sourceUrl;
global.APIs = {};
global.APIKeys = {};
global.packname = "[ STICKER BY ALUXI - MD ]";
global.author = ``;
global.domain = "https://syaiipanel.pannelkuu.biz.id";

global.apikey = "ptla_bFyeP32l9RbrFZ02sMHX9W59sMdDo5WDnhgbMxfrdkj";

global.multiplier = 100;
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase();
    let emot = {
      exp: "✉️",
      money: "💵",
      potion: "🥤",
      diamond: "💎",
      common: "📦",
      uncommon: "🎁",
      mythic: "🗳️",
      legendary: "🗃️",
      pet: "🎁",
      sampah: "🗑",
      armor: "🥼",
      sword: "⚔️",
      kayu: "🪵",
      batu: "🪨",
      string: "🕸️",
      kuda: "🐎",
      kucing: "🐈",
      anjing: "🐕",
      petFood: "🍖",
      gold: "👑",
      emerald: "💚",
    };
    let results = Object.keys(emot)
      .map((v) => [v, new RegExp(v, "gi")])
      .filter((v) => v[1].test(string));
    if (!results.length) return "";
    else return emot[results[0][0]];
  },
};

global.danied = {
  contextInfo: {
    mentionedJid: [],
    groupMentions: [],
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363144038483540@newsletter",
      newsletterName: "ALUXI - MD",
      serverMessageId: -1,
    },
    forwardingScore: 256,
    externalAdReply: {
      title: `[ x ] ACCESS DENIED`,
      body: null,
      thumbnailUrl: "https://telegra.ph/file/02989972e9117495fe747.jpg",
      sourceUrl: sgc,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
  },
};
let fs = require("fs");
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log("Update config.js");
  delete require.cache[file];
  require(file);
});