const axios = require("axios"); // <-- User Cjs
//import axios from "axios" <- User Esm 

let handler = async (m, {
    conn,
    usedPrefix,
    command,
    text
}) => {
    switch (command) {
        case "ytv":  // <- Buat user case Copas aja bagian case nya
        case "ytmp4": {
            if (!text) throw `*• Example :* ${usedPrefix + command} https://youtu.be/VPIom0Azrkg`
            m.reply("Downloading....")
            let {
                data
            } = await axios.get("https://api.botwa.space/api/ytmp4?url=" + text + "&apikey=fFUzSrI1ZcD3").catch((e) => e.response);
            if (!data.result) return data.message
            let cap = `${data.result.title}

* *Metadata Info :*
${Object.entries(data.result.metadata).map(([a, b]) => `- ${a} : ${b}`).join("\n")}

YouTube Downloader by ${data.creator}`
            await conn.sendMessage(m.chat, {
                video: {
                    url: data.result.media
                },
                caption: cap
            }, {
                quoted: m
            });
        }
      break
    }
}
handler.help = handler.command = ["ytmp4", "ytv"]
handler.tags = ["downloader"]

module.exports = handler