/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let thx = `*SPECIAL THANK FOR:*

*CREATOR BOT:* 
*• ALVIAN UXIO Inc. ( DEV )*
*• KARUTA MD ( MY INSPIRATION )*
*• R.A ZENIN BOT ( MY INSPIRATION )*
*• BOTCHAHX ( BASE BOT )*
*• AKIRAA TEAM ( PENYEMANGAT )*
*• AYGEMUY*
*• ARIFZYN*
*ALL BINARYCRAFTERS TEAM*
*ALL CREATOR*

*WEBSITE API:*
*• LOLHUMAN API*
=> https://api.lolhuman.xyz
*• ROSE API*
=> https://docs.itsrose.life
*• SKIZO API*
=> https://skizo.tech

*OTHER*
*• USER ALUXI - MD*
*• PREMIUM USER*
*• MODERATOR USER*

_♥️ Terima kasih telah selalu menggunakan ALUXI - MD sebagai bot WhatsApp andalan anda, semoga di depannya bot ini akan selalu update fitur yang menarik dan buat yang mau berdonasi untuk pengembangan bot ini ketik *.owner* untuk mulai berdonasi_`
m.reply(thx)
}
handler.command = handler.help = ["tqto"]
handler.tags = ["info"]
module.exports = handler