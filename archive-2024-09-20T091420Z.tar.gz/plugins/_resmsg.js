async function before(m, { isAdmin, isBotAdmin }) {
    if (m.isBaileys && m.fromMe) return;
    let msgs = global.db.data.msgs;

    let foundKey = Object.keys(msgs).find(key => m.text.startsWith(key));
    if (!foundKey) return;
    if (/\d{5,16}@s\.whatsapp\.net$/.test(foundKey)) {
        return;
    }

    let _m = this.serializeM(JSON.parse(JSON.stringify(msgs[foundKey]), (_, v) => {
        if (
            v !== null &&
            typeof v === 'object' &&
            'type' in v &&
            v.type === 'Buffer' &&
            'data' in v &&
            Array.isArray(v.data)
        ) {
            return Buffer.from(v.data);
        }
        return v;
    }));

    // Kirim pesan yang sudah diserialisasi
   await _m.copyNForward(m.chat, { quoted: m })
}

module.exports = {
    before,
};