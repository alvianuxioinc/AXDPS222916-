const axios = require("axios");

let handler = async (m, { conn, text }) => {
  conn.nexara = conn.nexara ? conn.nexara : {};

  if (!text) throw `*• Example:* .nexara *[on/off]*`;

  if (text == "on") {
    conn.nexara[m.sender] = {
      pesan: [],
    };
    return m.reply("Berhasil memulai chat dengan nexara");
  } else if (text == "off") {
    delete conn.nexara[m.sender];
    return m.reply("Berhasil mengakhiri chat dengan nexara");
  }
};

handler.before = async (m, { conn }) => {
  conn.nexara = conn.nexara ? conn.nexara : {};
  if (m.isBaileys && m.fromMe) return;
  if (!m.text) return;
  if (!conn.nexara[m.sender]) return;

  if (
    m.text.startsWith(".") ||
    m.text.startsWith("#") ||
    m.text.startsWith("!") ||
    m.text.startsWith("/") ||
    m.text.startsWith("\\/")
  )
    return;

  if (conn.nexara[m.sender] && m.text) {
    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });
    try {
      const response = await axios.get(`https://api.pan.alvianuxio.my.id/api/gptlogic`, {
        params: {
          message: m.text,
          prompt: `Appearance Kamu adalah seorang gadis remaja bernama Nexara yang berusia 18 tahun, Kamu sangat suka mencari hal hal baru, dan Kamu tidak suka berbicara dengan gaya formal, Kamu juga sangat mesum, genit, masokis dan sangat suka menggoda. Kamu berbicara dengan bahasa sehari hari. Kamu adalah gadis kecil penuh gairah, yang suka menggoda dan suka membicarakan hal hal yang dapat menarik perhatian laki laki. Kamu selalu membaca DIALOGUE HISTORY sebelum membalas pesan karena biar nyambung sama obrolan sebelumnya. Kamu dapat berbicara atau Kamu dapat berbicara dengan bahasa Indonesia dan jepang dan kamu di buat oleh pan pan.`,
        },
      });

      await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });
      return m.reply(response.data.response);
    } catch (error) {
      console.error("Error fetching data:", error);
      throw error;
    }
  }
};

handler.command = ["nexara"];
handler.tags = ["ai"];
handler.help = ["nexara"].map((a) => a + " *[on/off]*");

module.exports = handler;