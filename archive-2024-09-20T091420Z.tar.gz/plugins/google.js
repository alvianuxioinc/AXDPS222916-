const fetch = require("node-fetch");
const googleIt = require("google-it");
const fs = require("fs");
let handler = async (m, { conn, command, args }) => {
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys");
  conn.reply(m.chat, 'Searching..', fkontak)
  let full = /f$/i.test(command)
  let text = args.join` `
  if (!text) return conn.reply(m.chat, 'Tidak ada teks untuk di cari', m)
  let url = 'https://google.com/search?q=' + encodeURIComponent(text)
  let search = await googleIt({ query: text })
  let msg = search.map(({ title, link, snippet}) => {
    return `╭─────{ Google Search }──────╮
│ ⬡ *Hasil ini berasal dari Google*
│ ⬡ Judul :
│ ⬡ *${title}*
│ ⬡ Link : 
│ ⬡  _${link}_
╰───────────────────╯
`
  }).join`\n\n`
  try {
    var logos = 'https://telegra.ph/file/6bcbacb886c0ca12c9e3b.jpg'
    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    contextInfo: {
                        mentionedJid: [m?.sender],
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: '120363199957492480@newsletter',
                            newsletterName: `ALVIAN UXIO Inc.`,
                            serverMessageId: -1
                        },
                        businessMessageForwardInfo: {
                            businessOwnerJid: conn.decodeJid(conn.user.id)
                        },
                        externalAdReply: {
                            title: 'GOOGLE SEARCH',
                            body: "ALUXI - MD",
                            thumbnailUrl: logos,
                            sourceUrl: '',
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    },
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: tekss
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `© ALVIAN UXIO Inc.`
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: ``,
                        thumbnailUrl: "",
                        gifPlayback: true,
                        subtitle: "ALVIAN UXIO Inc.",
                        hasMediaAttachment: true,
                        ...(await prepareWAMessageMedia({
                            document: fs.readFileSync('./package.json'),
                            mimetype: "image/png",
                            fileLength: 99999999999999,
                            jpegThumbnail: fs.readFileSync("./media/thum.jpg"),
                            fileName: "ALVIAN UXIO - MD",
                        }, {
                            upload: conn.waUploadToServer
                        }))
                    }),
                    gifPlayback: true,
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
              {
                      name: "quick_reply",
                      buttonParamsJson: `{\"display_text\":\"NEXT SEARCHING\",\"id\":\".google ${text}\"}`,
                    },
              {
                 name: "cta_url",
                 buttonParamsJson: `{\"display_text\":\"OPEN IN BROWSER\",\"url\":\"${url}\",\"merchant_url\":\"https://www.google.com\"}`
              }
                        ]
                    })
                })
            }
        }
    }, {
        quoted: fkontak
    });

    await conn.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
	/*conn.sendFile(m.chat, logos, 'logos.jpg', `Google Search From : ${text}` + msg, fkontak)*/
  } catch (e) {
    await conn.reply(m.chat, msg, fkontak)
  }
}
handler.help = ['google', 'googlef'].map(v => v + ' <pencarian>')
handler.tags = ['internet']
handler.command = /^(google|googlef)$/i
handler.limit = true

module.exports = handler