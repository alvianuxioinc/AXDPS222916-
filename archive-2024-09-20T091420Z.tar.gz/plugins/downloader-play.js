const yuhu = require('yt-search');
const { youtube } = require("btch-downloader");
let handler = async (m, { command, conn, text }) => {  
   if (!text) return m.reply(command + ' Utopia')
   m.reply(wait)
      let url = await yuhu(text)
    
    let yt = url.videos[Math.floor(Math.random() * url.videos.length)]

  let url1 = `${yt.url}`;

       let audioUrl;
 try {
 audioUrl = await youtube(url1);
 } catch (e) {

 audioUrl = await youtube(url1);
 }
      let botku = `∘ Title :  ${yt.title} \n∘ Duration : ${yt.duration} \n∘ Views : ${~yt.views} \n∘ Id : ${yt.videoId} \n∘ Upload : ${yt.ago} \n∘ Url: ${yt.url}\n\nMohon tunggu, audio sedang dikirim...`
   
      await conn.sendMessage(m.chat, {
                    text: botku,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: "YOUTUBE PLAY",
                            body: "© ALUXI - MD",
                            thumbnailUrl: yt.image,
                            sourceUrl: '-',
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: m
                })
    conn.sendMessage(m.chat, { react: { text: '📥', key: m.key }});
 
		await conn.sendMedia(m.chat, audioUrl.mp3, m);
     
            conn.sendMessage(m.chat, { react: { text: '🎧', key: m.key }})
      

}


handler.help = handler.command = ['play'];
handler.tags = ['downloader'];

module.exports = handler;