const fetch = require('node-fetch')
let handler = async (m, { conn, usedPrefix, command, text }) => {
if (!text) return m.reply(`• *Example :* ${usedPrefix}${command} *[mediafire url]*`)
m.reply(wait)
let res = await fetch(`https://api.ssateam.my.id/api/mediafire?url=${text}`)
let x = await res.json()
let { url, url2, filename, ext, aploud, filesize, filesizeH } = x
let p = `*[ MEDIAFIRE DOWNLOADER ]*
*• File Name :* ${x.data.response.filename}
*• Type :* ${x.data.response.filetype}
*• Size :* ${x.data.response.filesize}
*• Upload :* ${x.data.response.uploadAt}`
conn.sendMessage(m.chat, {
text: p,
contextInfo: {
externalAdReply: {  
title: "MEDIAFIRE DOWNLOADER",
body: 'MEDIAFIRE DOWNLOADER BY ALUXI - MD',
thumbnailUrl: 'https://telegra.ph/file/6bcbacb886c0ca12c9e3b.jpg',
sourceUrl: "-",
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
    await conn.sendMessage(m.chat, {
  document: {
    url: x.data.response.link
  },
mimetype: `application/${x.data.response.filetype}`,
  fileName: `${x.data.response.filename}`,
  caption: "*SUCCCES*",
  contextInfo: {
    externalAdReply: {
      title: 'MEDIAFIRE DOWNLOADER',
      body: 'MEDIAFIRE DOWNLOADER BY ALUXI - MD',
      thumbnailUrl: 'https://telegra.ph/file/60d4d4c62a6f6ce43aa66.jpg',
      sourceUrl: "-",
      mediaType: 1,
      renderLargerThumbnail: true
    }
  }
}, { quoted: m });
}
handler.help = ["mediafire"].map((a) => a + " *[url]*");
handler.tags = ["downloader"];
handler.command = ["mediafire","mf"];

module.exports = handler;