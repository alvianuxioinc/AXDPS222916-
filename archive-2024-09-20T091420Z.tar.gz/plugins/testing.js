const axios = require("axios");
const yts = require("yt-search");
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
  if (!text) return m.reply(`${command} Utopia`)
  try {
    let yt = await yts(text);
    let json = await axios.get('https://api.alyachan.dev/api/yta?url=' + yt + '&apikey=PjSZY9')
    m.reply('Wait')
    let ca = `  ∘  Title : ` + json.data.title + `\n`
    ca += `  ∘  Duration : ` + json.data.duration + `\n`
    ca += `  ∘  Viewer : ` + json.data.views + `\n`
    ca += `  ∘  Size : ` + json.data.data.size
    conn.sendFile(m.chat, json.data.thumbnail, '', ca, m).then(async () => {
      await conn.sendMessage(m.chat, {
        document: { url: json.data.data.url },
        mimetype: 'audio/mp3',
        fileName: json.data.title + '.mp3'
      }, { quoted: m })
    })
  } catch (e) {
    console.log(e)
    return m.reply(e)
  }
}
handler.command = handler.help = ["testing"]
module.exports = handler